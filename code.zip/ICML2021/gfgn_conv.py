import torch
from torch.nn import Parameter, Linear
import torch.nn.functional as F
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.utils import remove_self_loops, add_self_loops, softmax
from torch_geometric.utils import add_remaining_self_loops

from torch_geometric.nn.inits import glorot, zeros
import torch_scatter
from torch import Tensor

def gcn_norm(edge_index, edge_weight=None, num_nodes=None, improved=False,
             add_self_loops=True, dtype=None):

    fill_value = 2. if improved else 1.

    # num_nodes = maybe_num_nodes(edge_index, num_nodes)

    if edge_weight is None:
        edge_weight = torch.ones((edge_index.size(1), ), dtype=dtype,
                                 device=edge_index.device)

    if add_self_loops:
        edge_index, tmp_edge_weight = add_remaining_self_loops(
            edge_index, edge_weight, fill_value, num_nodes)
        assert tmp_edge_weight is not None
        edge_weight = tmp_edge_weight

    row, col = edge_index[0], edge_index[1]
    deg = torch_scatter.scatter_add(edge_weight, col, dim=0, dim_size=num_nodes)
    deg_inv_sqrt = deg.pow(-0.5)
    # deg_inv_sqrt = deg.pow_(-0.5)
    deg_inv_sqrt.masked_fill_(deg_inv_sqrt == float('inf'), 0)
    return edge_index, deg_inv_sqrt[row] * edge_weight * deg_inv_sqrt[col], deg


class GATConv(MessagePassing):
    r"""The graph attentional operator from the `"Graph Attention Networks"
    <https://arxiv.org/abs/1710.10903>`_ paper

    .. math::
        \mathbf{x}^{\prime}_i = \alpha_{i,i}\mathbf{\Theta}\mathbf{x}_{i} +
        \sum_{j \in \mathcal{N}(i)} \alpha_{i,j}\mathbf{\Theta}\mathbf{x}_{j},

    where the attention coefficients :math:`\alpha_{i,j}` are computed as

    .. math::
        \alpha_{i,j} =
        \frac{
        \exp\left(\mathrm{LeakyReLU}\left(\mathbf{a}^{\top}
        [\mathbf{\Theta}\mathbf{x}_i \, \Vert \, \mathbf{\Theta}\mathbf{x}_j]
        \right)\right)}
        {\sum_{k \in \mathcal{N}(i) \cup \{ i \}}
        \exp\left(\mathrm{LeakyReLU}\left(\mathbf{a}^{\top}
        [\mathbf{\Theta}\mathbf{x}_i \, \Vert \, \mathbf{\Theta}\mathbf{x}_k]
        \right)\right)}.

    Args:
        in_channels (int): Size of each input sample.
        out_channels (int): Size of each output sample.
        heads (int, optional): Number of multi-head-attentions.
            (default: :obj:`1`)
        concat (bool, optional): If set to :obj:`False`, the multi-head
            attentions are averaged instead of concatenated.
            (default: :obj:`True`)
        negative_slope (float, optional): LeakyReLU angle of the negative
            slope. (default: :obj:`0.2`)
        dropout (float, optional): Dropout probability of the normalized
            attention coefficients which exposes each node to a stochastically
            sampled neighborhood during training. (default: :obj:`0`)
        bias (bool, optional): If set to :obj:`False`, the layer will not learn
            an additive bias. (default: :obj:`True`)
        **kwargs (optional): Additional arguments of
            :class:`torch_geometric.nn.conv.MessagePassing`.
    """

    def __init__(self, in_channels, out_channels, heads=1, concat=True,
                 negative_slope=0.2, dropout=0, bias=True, **kwargs):
        super(GATConv, self).__init__(aggr='add') #, **kwargs)

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.heads = heads
        self.concat = concat
        self.negative_slope = negative_slope
        self.dropout = dropout

        self.weight = Parameter(
            torch.Tensor(in_channels, heads * out_channels))
        self.att = Parameter(torch.Tensor(1, heads, 2 * out_channels))

        if bias and concat:
            self.bias = Parameter(torch.Tensor(heads * out_channels))
        elif bias and not concat:
            self.bias = Parameter(torch.Tensor(out_channels))
        else:
            self.register_parameter('bias', None)

        self.reset_parameters()

    def reset_parameters(self):
        glorot(self.weight)
        glorot(self.att)
        zeros(self.bias)

    def forward(self, x, edge_index, size=None):
        """"""
        if size is None and torch.is_tensor(x):
            edge_index, _ = remove_self_loops(edge_index)
            edge_index, _ = add_self_loops(edge_index, num_nodes=x.size(0))

        if torch.is_tensor(x):
            x = torch.matmul(x, self.weight)
        else:
            x = (None if x[0] is None else torch.matmul(x[0], self.weight),
                 None if x[1] is None else torch.matmul(x[1], self.weight))

        return self.propagate(edge_index, size=size, x=x)

    def message(self, edge_index_i, x_i, x_j, size_i):
        # Compute attention coefficients.

        x_j = x_j.view(-1, self.heads, self.out_channels)
        if x_i is None:
            alpha = (x_j * self.att[:, :, self.out_channels:]).sum(dim=-1)
        else:
            x_i = x_i.view(-1, self.heads, self.out_channels)
            alpha = (torch.cat([x_i, x_j], dim=-1) * self.att).sum(dim=-1)

        alpha = F.leaky_relu(alpha, self.negative_slope)
        alpha = softmax(alpha, edge_index_i, size_i)

        # Sample attention coefficients stochastically.
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)

        return x_j * alpha.view(-1, self.heads, 1)

    def update(self, aggr_out):

        if self.concat is True:
            aggr_out = aggr_out.view(-1, self.heads * self.out_channels)
        else:
            aggr_out = aggr_out.mean(dim=1)

        if self.bias is not None:
            aggr_out = aggr_out + self.bias
        return aggr_out

    def __repr__(self):
        return '{}({}, {}, heads={})'.format(self.__class__.__name__,
                                             self.in_channels,
                                             self.out_channels, self.heads)


class GFGNConv1(MessagePassing):
    """
    Graph Smoothing
    """

    def __init__(self, in_channels, out_channels, heads=1, concat=True,
                 negative_slope=0.2, dropout=0, bias=True, **kwargs):
        super(GFGNConv1, self).__init__(aggr='add') #, **kwargs)

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.heads = heads
        self.concat = concat
        self.negative_slope = negative_slope
        self.dropout = dropout

        self.weight = Parameter(
            torch.Tensor(in_channels, heads * out_channels))
        # self.att = Parameter(torch.Tensor(1, heads, 2 * out_channels))
        self.feat_att = Parameter(torch.Tensor(out_channels, heads, out_channels))
        self.feat_att_bias = Parameter(torch.Tensor(heads, out_channels))

        # self.score = Parameter(torch.Tensor(1, heads * out_channels))

        self._cached_edge_index = None
        self._cached_adj_t = None

        if bias and concat:
            self.bias = Parameter(torch.Tensor(heads * out_channels))
        elif bias and not concat:
            self.bias = Parameter(torch.Tensor(out_channels))
        else:
            self.register_parameter('bias', None)

        self.reset_parameters()
        self.deg = None
        self.lambda_ = kwargs['lambda_']

    def reset_parameters(self):
        # torch.nn.init.xavier_normal_(self.score.data, gain=1.414)
        glorot(self.weight)
        # glorot(self.att)
        glorot(self.feat_att)
        zeros(self.bias)
        zeros(self.feat_att_bias)

    def forward(self, x, edge_index, size=None):
        """"""
        if isinstance(edge_index, Tensor):
            cache = self._cached_edge_index
            if cache is None:
                edge_weight = None
                edge_index, self.edge_weight, self.deg = gcn_norm(  # yapf: disable
                    edge_index, edge_weight, x.size(0),
                    False, add_self_loops=True, dtype=x.dtype)
                self.deg = self.deg.view(-1, 1, 1)
                # if self.cached:
                #     self._cached_edge_index = (edge_index, edge_weight)
            else:
                edge_index, self.edge_weight = cache[0], cache[1]


        if torch.is_tensor(x):
            x = torch.matmul(x, self.weight)
            self.x = x.view(-1, self.heads, self.out_channels)
            self.graph_message = x.mean(0).view(-1, self.heads, self.out_channels)
        else:
            x = (None if x[0] is None else torch.matmul(x[0], self.weight),
                 None if x[1] is None else torch.matmul(x[1], self.weight))

        return self.propagate(edge_index, size=size, x=x)

    def message(self, edge_index_i, x_i, x_j, size_i):
        # Compute attention coefficients.

        x_j = self.edge_weight.view(-1, 1) * x_j
        x_j = x_j.view(-1, self.heads, self.out_channels)

        if x_i is not None:
            x_i = x_i.view(-1, self.heads, self.out_channels)

        def mapper(idx):
            alpha = (self.graph_message * self.feat_att[idx]).sum(-1) + self.feat_att_bias[:, idx]
            alpha = self.lambda_ * torch.sigmoid(alpha)
            return alpha

        alpha = torch.stack([mapper(idx) for idx in range(self.out_channels)], dim=-1)
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)
        self.alpha = alpha

        return x_j * alpha.view(-1, self.heads, self.out_channels)
        # return x_j * alpha.view(-1, self.heads, 1)

    def update(self, aggr_out):
        aggr_out = self.x - self.alpha * (self.x) + aggr_out

        if self.concat is True:
            aggr_out = aggr_out.view(-1, self.heads * self.out_channels)
        else:
            aggr_out = aggr_out.mean(dim=1)

        if self.bias is not None:
            aggr_out = aggr_out + self.bias
        return aggr_out

    def __repr__(self):
        return '{}({}, {}, heads={})'.format(self.__class__.__name__,
                                             self.in_channels,
                                             self.out_channels, self.heads)


class GFGNConv2(MessagePassing):
    """ Neighborhood level smoothing
    """

    def __init__(self, in_channels, out_channels, heads=1, concat=True,
                 negative_slope=0.2, dropout=0, bias=True, **kwargs):
        # super(GFGNConv2, self).__init__(aggr='add', **kwargs)
        super(GFGNConv2, self).__init__(aggr='add') #, **kwargs)

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.heads = heads
        self.concat = concat
        self.negative_slope = negative_slope
        self.dropout = dropout

        self.weight = Parameter(
            torch.Tensor(in_channels, heads * out_channels))
        # self.att = Parameter(torch.Tensor(1, heads, 2 * out_channels))
        self.feat_att = Parameter(torch.Tensor(out_channels, heads, 2 * out_channels))
        self.feat_att_bias = Parameter(torch.Tensor(heads, out_channels))

        if bias and concat:
            self.bias = Parameter(torch.Tensor(heads * out_channels))
        elif bias and not concat:
            self.bias = Parameter(torch.Tensor(out_channels))
        else:
            self.register_parameter('bias', None)

        self.reset_parameters()
        self.deg = None
        self._cached_edge_index = None
        self._cached_adj_t = None
        self.lambda_ = kwargs['lambda_']

    def reset_parameters(self):
        glorot(self.weight)
        # glorot(self.att)
        glorot(self.feat_att)
        zeros(self.bias)
        zeros(self.feat_att_bias)

    def forward(self, x, edge_index, size=None):
        """"""
        if isinstance(edge_index, Tensor):
            cache = self._cached_edge_index
            if cache is None:
                edge_weight = None
                edge_index, self.edge_weight, self.deg = gcn_norm(  # yapf: disable
                    edge_index, edge_weight, x.size(0),
                    False, add_self_loops=True, dtype=x.dtype)
                self.deg = self.deg.view(-1, 1, 1)
            else:
                edge_index, self.edge_weight = cache[0], cache[1]

        if torch.is_tensor(x):
            x = torch.matmul(x, self.weight)
            edge_weight = torch.ones((edge_index.size(1), ),
                         device=edge_index.device)
            inputs = edge_weight.view(-1, 1) * x[edge_index[0]]
            self.neighbor_message = torch_scatter.scatter_mean(inputs, edge_index[1], dim=-2)
        else:
            x = (None if x[0] is None else torch.matmul(x[0], self.weight),
                 None if x[1] is None else torch.matmul(x[1], self.weight))

        self.x = x
        if self.deg is None:
            row, col = edge_index[0], edge_index[1]
            self.deg = torch_scatter.scatter_add(edge_weight, col, dim=0, dim_size=x.size(0)).view(-1,1,1)
        return self.propagate(edge_index, size=size, x=x)

    def message(self, edge_index_i, x_i, x_j, size_i):
        # Compute attention coefficients.

        x_j = self.edge_weight.view(-1, 1) * x_j
        x_j = x_j.view(-1, self.heads, self.out_channels)
        x = self.x.view(-1, self.heads, self.out_channels)
        self.x = x
        neighbor_message = self.neighbor_message.view(-1, self.heads, self.out_channels)

        if x_i is not None:
            x_i = x_i.view(-1, self.heads, self.out_channels)

        def mapper(idx):
            alpha = (torch.cat([x, neighbor_message], dim=-1) * self.feat_att[idx]).sum(dim=-1) + self.feat_att_bias[:, idx]
            alpha = self.lambda_ * torch.sigmoid(alpha)
            return alpha

        alpha = torch.stack([mapper(idx) for idx in range(self.out_channels)], dim=-1)

        # Sample attention coefficients stochastically.
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)
        self.alpha = alpha

        return x_j * alpha[edge_index_i].view(-1, self.heads, self.out_channels)

    def _message(self, edge_index_i, x_i, x_j, size_i):
        # Compute attention coefficients.

        x_j = x_j.view(-1, self.heads, self.out_channels)

        neighbor_message = self.neighbor_message[edge_index_i].view(-1, self.heads, self.out_channels)
        if x_i is not None:
            x_i = x_i.view(-1, self.heads, self.out_channels)

        def mapper(idx):
            if x_i is None:
                alpha = (x_j * self.att[:, :, self.out_channels:]).sum(dim=-1)
            else:
                alpha = (torch.cat([x_i, neighbor_message], dim=-1) * self.att).sum(dim=-1) + self.feat_att_bias[:, idx]

            alpha = F.leaky_relu(alpha, self.negative_slope)
            alpha = softmax(alpha, edge_index_i, size_i)
            return alpha

        alpha = torch.stack([mapper(idx) for idx in range(self.out_channels)], dim=-1)

        # Sample attention coefficients stochastically.
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)
        self.alpha = alpha[edge_index_i]

        return x_j * alpha.view(-1, self.heads, self.out_channels)

    def update(self, aggr_out):
        aggr_out = self.x - self.alpha * self.x + aggr_out

        if self.concat is True:
            aggr_out = aggr_out.view(-1, self.heads * self.out_channels)
        else:
            aggr_out = aggr_out.mean(dim=1)

        if self.bias is not None:
            aggr_out = aggr_out + self.bias
        return aggr_out

    def __repr__(self):
        return '{}({}, {}, heads={})'.format(self.__class__.__name__,
                                             self.in_channels,
                                             self.out_channels, self.heads)


class GFGNConv3(MessagePassing):
    """
    Pairwise Smoothing
    """

    def __init__(self, in_channels, out_channels, heads=1, concat=True,
                 negative_slope=0.2, dropout=0, bias=True, **kwargs):
        super(GFGNConv3, self).__init__(aggr='add')

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.heads = heads
        self.concat = concat
        self.negative_slope = negative_slope
        self.dropout = dropout

        self.weight = Parameter(
            torch.Tensor(in_channels, heads * out_channels))
        self.att = Parameter(torch.Tensor(1, heads, 2 * out_channels))
        self.feat_att = Parameter(torch.Tensor(out_channels, heads, 2 * out_channels))

        if bias and concat:
            self.bias = Parameter(torch.Tensor(heads * out_channels))
        elif bias and not concat:
            self.bias = Parameter(torch.Tensor(out_channels))
        else:
            self.register_parameter('bias', None)

        self.reset_parameters()

    def reset_parameters(self):
        glorot(self.weight)
        glorot(self.att)
        glorot(self.feat_att)
        zeros(self.bias)

    def forward(self, x, edge_index, size=None):
        """"""
        if size is None and torch.is_tensor(x):
            edge_index, _ = remove_self_loops(edge_index)
            edge_index, _ = add_self_loops(edge_index, num_nodes=x.size(0))

        if torch.is_tensor(x):
            x = torch.matmul(x, self.weight)
        else:
            x = (None if x[0] is None else torch.matmul(x[0], self.weight),
                 None if x[1] is None else torch.matmul(x[1], self.weight))

        return self.propagate(edge_index, size=size, x=x)

    def message(self, edge_index_i, x_i, x_j, size_i):
        # Compute attention coefficients.

        x_j = x_j.view(-1, self.heads, self.out_channels)

        if x_i is not None:
            x_i = x_i.view(-1, self.heads, self.out_channels)

        def mapper(idx):
            alpha = (torch.cat([x_i, x_j], dim=-1) * self.feat_att[idx]).sum(dim=-1)
            alpha = F.leaky_relu(alpha, self.negative_slope)
            # alpha = torch.sigmoid(alpha)
            alpha = softmax(alpha, edge_index_i, size_i)
            return alpha

        alpha = torch.stack([mapper(idx) for idx in range(self.out_channels)], dim=-1)

        # Sample attention coefficients stochastically.
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)

        return x_j * alpha.view(-1, self.heads, self.out_channels)
        # return x_j * alpha.view(-1, self.heads, 1)

    def update(self, aggr_out):
        if self.concat is True:
            aggr_out = aggr_out.view(-1, self.heads * self.out_channels)
        else:
            aggr_out = aggr_out.mean(dim=1)

        if self.bias is not None:
            aggr_out = aggr_out + self.bias
        return aggr_out

    def __repr__(self):
        return '{}({}, {}, heads={})'.format(self.__class__.__name__,
                                             self.in_channels,
                                             self.out_channels, self.heads)



class GFGNConv4(MessagePassing):
    """
    Pairwise Smoothing - (1-alpha)x_i + alpha x_j
    """

    def __init__(self, in_channels, out_channels, heads=1, concat=True,
                 negative_slope=0.2, dropout=0, bias=True, **kwargs):
        # super(GFGNConv3, self).__init__(aggr='add', **kwargs)
        super(GFGNConv4, self).__init__(aggr='add')

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.heads = heads
        self.concat = concat
        self.negative_slope = negative_slope
        self.dropout = dropout

        self.weight = Parameter(
            torch.Tensor(in_channels, heads * out_channels))
        self.feat_att = Parameter(torch.Tensor(out_channels, heads, 2 * out_channels))
        self.feat_att_bias = Parameter(torch.Tensor(heads, out_channels))

        if bias and concat:
            self.bias = Parameter(torch.Tensor(heads * out_channels))
        elif bias and not concat:
            self.bias = Parameter(torch.Tensor(out_channels))
        else:
            self.register_parameter('bias', None)

        self.reset_parameters()
        self._cached_edge_index = None
        self._cached_adj_t = None
        self.lambda_ = kwargs['lambda_']

    def reset_parameters(self):
        glorot(self.weight)
        glorot(self.feat_att)
        zeros(self.bias)
        zeros(self.feat_att_bias)

    def forward(self, x, edge_index, size=None):
        """"""
        if isinstance(edge_index, Tensor):
            cache = self._cached_edge_index
            if cache is None:
                edge_weight = None
                edge_index, self.edge_weight, self.deg = gcn_norm(  # yapf: disable
                    edge_index, edge_weight, x.size(0),
                    False, add_self_loops=True, dtype=x.dtype)
                self.deg = self.deg.view(-1, 1, 1)
                # if self.cached:
                #     self._cached_edge_index = (edge_index, edge_weight)
            else:
                edge_index, self.edge_weight = cache[0], cache[1]

        if torch.is_tensor(x):
            x = torch.matmul(x, self.weight)
        else:
            x = (None if x[0] is None else torch.matmul(x[0], self.weight),
                 None if x[1] is None else torch.matmul(x[1], self.weight))

        self.x = x.view(-1, self.heads, self.out_channels)
        return self.propagate(edge_index, size=size, x=x)

    def message(self, edge_index_i, x_i, x_j, size_i):
        # Compute attention coefficients.

        x_j = self.edge_weight.view(-1, 1) * x_j
        x_j = x_j.view(-1, self.heads, self.out_channels)

        if x_i is not None:
            x_i = x_i.view(-1, self.heads, self.out_channels)

        def mapper(idx):
            alpha = (torch.cat([x_i, x_j], dim=-1) * self.feat_att[idx]).sum(dim=-1) + self.feat_att_bias[:, idx]
            alpha = self.lambda_ * torch.sigmoid(alpha)
            return alpha

        alpha = torch.stack([mapper(idx) for idx in range(self.out_channels)], dim=-1)
        self.alpha_pair = alpha

        self.alpha = torch_scatter.scatter_mean(alpha, edge_index_i, dim=0)
        # Sample attention coefficients stochastically.
        alpha = F.dropout(alpha, p=self.dropout, training=self.training)

        return x_j * alpha.view(-1, self.heads, self.out_channels)

    def update(self, aggr_out):

        aggr_out = self.x - self.alpha * self.x + aggr_out
        if self.concat is True:
            aggr_out = aggr_out.view(-1, self.heads * self.out_channels)
        else:
            aggr_out = aggr_out.mean(dim=1)

        if self.bias is not None:
            aggr_out = aggr_out + self.bias
        return aggr_out

    def __repr__(self):
        return '{}({}, {}, heads={})'.format(self.__class__.__name__,
                                             self.in_channels,
                                             self.out_channels, self.heads)




