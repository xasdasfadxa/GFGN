# python run_gat.py --dataset cora --model 1 --runs 10
python run_gat.py --dataset cora --model 2 --runs 100
python run_gat.py --dataset cora --model 3 --runs 100
